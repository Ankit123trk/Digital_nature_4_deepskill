package com.example.countryrestapi.dao;

import com.example.countryrestapi.model.Country;
import java.util.*;

import org.springframework.stereotype.Repository;

@Repository
public class CountryDao {

    private static Map<String, Country> countryMap = new HashMap<>();

    static {
        countryMap.put("IN", new Country("IN", "India", "New Delhi"));
        countryMap.put("US", new Country("US", "United States", "Washington"));
    }

    public Country getByCode(String code) {
        return countryMap.get(code.toUpperCase());
    }

    public List<Country> getAll() {
        return new ArrayList<>(countryMap.values());
    }

    public void add(Country country) {
        countryMap.put(country.getCode().toUpperCase(), country);
    }

    public void update(String code, Country updated) {
        countryMap.put(code.toUpperCase(), updated);
    }

    public void delete(String code) {
        countryMap.remove(code.toUpperCase());
    }
}
