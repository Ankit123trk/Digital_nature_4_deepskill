package inventory;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InventoryManager manager = new InventoryManager();

        // Add products
        Product p1 = new Product(111, "Mouse", 20, 650.00);
        Product p2 = new Product(112, "Keyboard", 10, 850.00);
        Product p3 = new Product(113, "Monitor", 5, 12990.00);

        manager.addProduct(p1);
        manager.addProduct(p2);
        manager.addProduct(p3);

        // Display
        System.out.println("\n Inventory ");
        manager.displayInventory();

        // Update
        System.out.println("\n Update Product 112");
        manager.updateProduct(112, "Wireless Keyboard", 15,1500.00);

        // Display
        manager.displayInventory();

        // Delete
        System.out.println("\n-- Delete Product 101 --");
        manager.deleteProduct(101);
        manager.deleteProduct(111);

        // Display
        manager.displayInventory();
	}

}
