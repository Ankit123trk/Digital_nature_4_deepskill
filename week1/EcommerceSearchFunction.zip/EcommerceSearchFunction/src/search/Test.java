package search;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product[] products = new Product[5];
        products[0] = new Product(101, "Mouse", "Electronics");
        products[1] = new Product(102, "Keyboard", "Electronics");
        products[2] = new Product(103, "Shoes", "Footwear");
        products[3] = new Product(104, "Shirt", "Clothing");
        products[4] = new Product(105, "Monitor", "Electronics");
        
        System.out.println("Linear Search for 'Shoes':");
        Product result1 = SearchFunction.linearSearch(products, "Shoes");
        if (result1 != null) result1.display();
        else System.out.println("Product not found.");
        
        System.out.println("\n Sorting for Binary Search");
        SearchFunction.sortProductsByName(products);
        
        System.out.println("\n Binary Search for 'Keyboard':");
        Product result2 = SearchFunction.binarySearch(products, "Keyboard");
        if (result2 != null) result2.display();
        else System.out.println("Product not found.");
	}

}
