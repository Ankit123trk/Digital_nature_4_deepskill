package com.example.mockdemo;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

/*
 *Exercise 1: Mocking and Stubbing 
Scenario: 
You need to test a service that depends on an external API. Use Mockito to mock the 
external API and stub its methods. 
 * */

public class MyServiceTest {
	  @Test
	    public void testExternalApi() {

	        ExternalApi mockApi = mock(ExternalApi.class);

	     
	        when(mockApi.getData()).thenReturn("Mock Data");

	        
	        MyService service = new MyService(mockApi);

	       
	        String result = service.fetchData();
	        assertEquals("Mock Data", result);
	    }
    //Exercise 2: Verifying Interactions 
   // Scenario: 
    //	You need to ensure that a method is called with specific arguments. 
    
    @Test
    public void testVerifyInteraction() {

        ExternalApi mockApi = mock(ExternalApi.class);

        
        MyService service = new MyService(mockApi);

      
        service.fetchData();

        
        verify(mockApi).getData(); 
    }
}
