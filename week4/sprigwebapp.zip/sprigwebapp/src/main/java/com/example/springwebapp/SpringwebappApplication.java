package com.example.springwebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication // Enables auto-configuration, component scanning, and more
public class SpringwebappApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringwebappApplication.class, args);
    }
}
