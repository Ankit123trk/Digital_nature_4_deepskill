package com.example.countryrestapi.model;

import jakarta.validation.constraints.*;

public class Country {

    @NotBlank(message = "Country code cannot be blank")
    @Size(min = 2, max = 3, message = "Country code must be 2-3 characters")
    private String code;

    @NotBlank(message = "Country name cannot be blank")
    private String name;

    @NotBlank(message = "Capital cannot be blank")
    private String capital;

    // Constructors, Getters, Setters
    public Country() {}

    public Country(String code, String name, String capital) {
        this.code = code;
        this.name = name;
        this.capital = capital;
    }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getCapital() { return capital; }
    public void setCapital(String capital) { this.capital = capital; }
}
