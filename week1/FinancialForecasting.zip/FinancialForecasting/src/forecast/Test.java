package forecast;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double presentValue = 1000.0;  // Initial amount
        double rate = 0.11;            // 10% growth per year
        int periods = 5;               //5 years forecasting
        
        double futureVal = FinancialForecast.futureValue(presentValue, rate, periods);
        System.out.println("Future Value : " + futureVal);

	}

}
