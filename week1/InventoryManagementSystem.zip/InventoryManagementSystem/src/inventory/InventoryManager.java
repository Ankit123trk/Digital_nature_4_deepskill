package inventory;

import java.util.HashMap;

public class InventoryManager {
    private HashMap<Integer, Product> inventory;

    public InventoryManager() {
        inventory = new HashMap<>();
    }

    // Adding new product
    public void addProduct(Product product) {
        int id = product.getProductId();
        if (inventory.containsKey(id)) {
            System.out.println("Product already exists!");
        } else {
            inventory.put(id, product);
            System.out.println("Product added.");
        }
    }

    // Update product details
    public void updateProduct(int id, String name, int qty, double price) {
        if (inventory.containsKey(id)) {
            Product p = inventory.get(id);
            p.setProductName(name);
            p.setQuantity(qty);
            p.setPrice(price);
            System.out.println("Product updated.");
        } else {
            System.out.println("Product not found!");
        }
    }

    // Delete product
    public void deleteProduct(int id) {
        if (inventory.containsKey(id)) {
            inventory.remove(id);
            System.out.println("Product deleted.");
        } else {
            System.out.println("Product not found!");
        }
    }

    // Display all products
    public void displayInventory() {
        if (inventory.isEmpty()) {
            System.out.println("Inventory is empty.");
        } else {
            for (Product p : inventory.values()) {
                p.displayProduct();
            }
        }
    }
}
