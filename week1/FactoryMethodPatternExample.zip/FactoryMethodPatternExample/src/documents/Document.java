package documents;

public interface Document {
	void open();
}
