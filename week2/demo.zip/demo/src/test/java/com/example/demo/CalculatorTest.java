package com.example.demo;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class CalculatorTest {
	 private Calculator calc;

	   
	    @Before
	    void setUp() {
	        calc = new Calculator();  // Arrange: setup shared object
	        System.out.println("Setup complete");
	    }

	    
	    @After
	    void tearDown() {
	        calc = null;
	        System.out.println("Teardown complete");
	    }

	    @Test
	    void testAddition() {
	        // Act
	        int result = calc.add(10, 5);

	        // Assert
	        assertEquals(15, result);
	    }

	    @Test
	    void testMultiplication() {
	        int result = calc.multiply(3, 4);
	        assertEquals(12, result);
	    }
}
