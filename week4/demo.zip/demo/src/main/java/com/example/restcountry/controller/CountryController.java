package com.example.restcountry.controller;

import com.example.restcountry.model.Country;
import org.springframework.web.bind.annotation.*;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@RestController
public class CountryController {

    // Simple GET - hardcoded
    @GetMapping("/country")
    public Country getCountry() {
        return new Country("India", "New Delhi");
    }
    
    @GetMapping("/country-xml")
    public Country getCountryFromXml() {
        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        return (Country) context.getBean("country");
    }

    // GET with parameter
    @GetMapping("/country/{name}")
    public Country getCountryByName(@PathVariable String name) {
        return new Country(name, "Capital of " + name);
    }

    // GET returning array of objects
    @GetMapping("/countries")
    public Country[] getAllCountries() {
        return new Country[] {
            new Country("India", "New Delhi"),
            new Country("USA", "Washington DC"),
            new Country("France", "Paris")
        };
    }
}
