package com.example.helloworldrest.dao;

import org.springframework.stereotype.Repository;

@Repository
public class HelloDao {
    public String getMessage() {
        return "Hello World from DAO!";
    }
}
