package com.example.countryrestapi.controller;

import com.example.countryrestapi.model.Country;
import com.example.countryrestapi.service.CountryService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/countries")
public class CountryController {

    @Autowired
    private CountryService service;

    @GetMapping("/{code}")
    public Country getCountry(@PathVariable String code) {
        return service.getCountry(code);
    }

    @GetMapping
    public List<Country> getAll() {
        return service.getAll();
    }

    @PostMapping
    public String addCountry(@Valid @RequestBody Country country) {
        service.add(country);
        return "Country added successfully";
    }

    @PutMapping("/{code}")
    public String updateCountry(@PathVariable String code, @Valid @RequestBody Country country) {
        service.update(code, country);
        return "Country updated successfully";
    }

    @DeleteMapping("/{code}")
    public String deleteCountry(@PathVariable String code) {
        service.delete(code);
        return "Country deleted successfully";
    }
}
