package com.example.mockdemo;

public interface ExternalApi {
    String getData();
}