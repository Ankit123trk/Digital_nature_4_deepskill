package com.example.demo;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AssertionsTest {
	  @Test
	    void testAssertions() {
	        // Check equality
	        assertEquals(5, 2 + 3, "Addition should equal 5");

	        // Check a true condition
	        assertTrue(5 > 3, "5 is greater than 3");

	        // Check a false condition
	        assertFalse(5 < 3, "5 is not less than 3");

	        // Check null value
	        Object obj1 = null;
	        assertNull(obj1, "Object should be null");

	        // Check not null
	        Object obj2 = new Object();
	        assertNotNull(obj2, "Object should not be null");
	    }
}
