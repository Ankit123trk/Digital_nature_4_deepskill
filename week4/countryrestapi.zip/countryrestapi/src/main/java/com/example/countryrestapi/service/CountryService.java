package com.example.countryrestapi.service;

import com.example.countryrestapi.dao.CountryDao;
import com.example.countryrestapi.model.Country;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CountryService {

    @Autowired
    private CountryDao dao;

    public Country getCountry(String code) {
        return dao.getByCode(code);
    }

    public List<Country> getAll() {
        return dao.getAll();
    }

    public void add(Country country) {
        dao.add(country);
    }

    public void update(String code, Country country) {
        dao.update(code, country);
    }

    public void delete(String code) {
        dao.delete(code);
    }
}
