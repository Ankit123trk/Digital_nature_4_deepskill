package com.example.demo.model;


public class JwtRequest {
    private String username;
    private String password;
    // Getters and Setters
}