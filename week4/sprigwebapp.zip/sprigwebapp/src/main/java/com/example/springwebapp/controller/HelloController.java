package com.example.springwebapp.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController // Marks this as a REST controller that returns responses
public class HelloController {

    @GetMapping("/") // Handles GET requests at http://localhost:8080/
    public String hello() {
        return "Hello, Spring Web!";
    }
}
