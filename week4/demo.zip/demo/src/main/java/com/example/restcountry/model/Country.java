package com.example.restcountry.model;

public class Country {
    private String name;
    private String capital;

    // Constructor
    public Country(String name, String capital) {
        this.name = name;
        this.capital = capital;
    }

    // Getters
    public String getName() {
        return name;
    }

    public String getCapital() {
        return capital;
    }
}
